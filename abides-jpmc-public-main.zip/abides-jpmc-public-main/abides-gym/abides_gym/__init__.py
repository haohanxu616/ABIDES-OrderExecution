try:
    from gymnasium.envs.registration import register as gym_register
except ImportError:
    from gym.envs.registration import register as gym_register

from ray.tune.registry import register_env

from .envs import *


# REGISTER ENVS FOR GYM/GYMNASIUM USE

gym_register(
    id="markets-daily_investor-v0",
    entry_point=SubGymMarketsDailyInvestorEnv_v0,
)

gym_register(
    id="markets-execution-v0",
    entry_point=SubGymMarketsExecutionEnv_v0,
)


# REGISTER ENVS FOR RAY/RLLIB USE

register_env(
    "markets-daily_investor-v0",
    lambda config: SubGymMarketsDailyInvestorEnv_v0(**config),
)

register_env(
    "markets-execution-v0",
    lambda config: SubGymMarketsExecutionEnv_v0(**config),
)
