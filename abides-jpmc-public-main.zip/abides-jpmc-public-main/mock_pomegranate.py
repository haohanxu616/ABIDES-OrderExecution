"""
Mock pomegranate module to provide compatibility with ABIDES
when pomegranate cannot be installed due to Python version incompatibility.
"""

import numpy as np
from typing import Any, List, Optional

class GeneralMixtureModel:
    """Mock GeneralMixtureModel class."""
    
    def __init__(self, distributions: List[Any], weights: Optional[List[float]] = None):
        self.distributions = distributions
        self.weights = weights or [1.0 / len(distributions)] * len(distributions)
    
    def fit(self, X: np.ndarray, *args, **kwargs):
        """Mock fit method."""
        pass
    
    def sample(self, n_samples: int = 1) -> np.ndarray:
        """Mock sample method - returns random samples."""
        return np.random.randn(n_samples, 1)
    
    def log_probability(self, X: np.ndarray) -> np.ndarray:
        """Mock log probability method."""
        return np.zeros(len(X))

class NormalDistribution:
    """Mock NormalDistribution class."""
    
    def __init__(self, mu: float = 0.0, sigma: float = 1.0):
        self.mu = mu
        self.sigma = sigma
    
    def sample(self, n_samples: int = 1) -> np.ndarray:
        """Sample from normal distribution."""
        return np.random.normal(self.mu, self.sigma, n_samples)
    
    def log_probability(self, X: np.ndarray) -> np.ndarray:
        """Calculate log probability."""
        return -0.5 * np.log(2 * np.pi * self.sigma**2) - 0.5 * ((X - self.mu) / self.sigma)**2
